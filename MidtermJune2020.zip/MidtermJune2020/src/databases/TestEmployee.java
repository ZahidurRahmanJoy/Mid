package databases;

public class TestEmployee {
    public static void main(String[] args) {
        Employee emp1 = new Employee();
        emp1.setEmpDOB("10-20-1980");
    }
}
