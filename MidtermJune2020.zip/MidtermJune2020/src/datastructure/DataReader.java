package datastructure;


public class DataReader {

	public static void main(String[] args) {
		}}